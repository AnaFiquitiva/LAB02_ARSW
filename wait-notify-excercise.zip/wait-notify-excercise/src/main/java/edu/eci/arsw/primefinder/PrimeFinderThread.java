package edu.eci.arsw.primefinder;

import java.util.List;
import java.util.ArrayList;

public class PrimeFinderThread extends Thread {
    private final int start;
    private final int end;
    private final List<Integer> primes = new ArrayList<>();
    private boolean paused = false;
    private final Object monitor;

    public PrimeFinderThread(int start, int end, Object monitor) {
        this.start = start;
        this.end = end;
        this.monitor = monitor;
    }

    public List<Integer> getPrimes() {
        return primes;
    }

    // Metodo para pausar el hilo
    public void pauseThread() {
        synchronized (monitor) {
            paused = true;
        }
    }

    // Metodo para reanudar el hilo
    public void resumeThread() {
        synchronized (monitor) {
            paused = false;
            monitor.notifyAll();
        }
    }

    // Metodo run que busca números primos en el rango [start, end) Utilizando el monitor para pausar y reanudar el hilo
    // Se agregó synchronized que utiliza wait() para detener el hilo cuando está en pausa y notifyAll() para reanudarlo.
    @Override
    public void run() {
        for (int i = start; i < end; i++) {
            synchronized (monitor) {
                while (paused) {
                    try {
                        monitor.wait(); // Espera a que se reanude
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
            }
            if (isPrime(i)) {
                primes.add(i);
            }
        }
    }


    private boolean isPrime(int n) {
        if (n <= 1) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public int getPrimesFound() {
        return primes.size();
    }

    public void setPaused(boolean b) {
        synchronized (monitor) {
            paused = b;
            if (!paused) {
                monitor.notifyAll();
            }
        }
    }
}
