/*+* Clase PauseController que gestiona la pausa y reanudación de hilos de búsqueda de números primos.
 * Permite pausar todos los hilos cada cierto intervalo, mostrar los números primos encontrados
 * hasta ese momento y esperar a que el usuario presione ENTER para reanudarlos.
*/
package edu.eci.arsw.primefinder;


import java.util.Scanner;

public class PauseController implements Runnable {
    private final int interval;
    private final Object monitor;
    private final PrimeFinderThread[] threads;

    public PauseController(int interval, Object monitor, PrimeFinderThread[] threads) {
        this.interval = interval;
        this.monitor = monitor;
        this.threads = threads;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Thread.sleep(interval);

                synchronized (monitor) {
                    // Pausar todos los hilos
                    for (PrimeFinderThread thread : threads) {
                        thread.pauseThread();
                    }

                    // Mostrar números primos encontrados
                    int totalPrimes = 0;
                    for (PrimeFinderThread thread : threads) {
                        totalPrimes += thread.getPrimes().size();
                    }
                    System.out.println("Números primos encontrados: " + totalPrimes);

                    // Esperar ENTER para reanudar
                    System.out.println("Presiona ENTER para continuar...");
                    new Scanner(System.in).nextLine();

                    // Reanudar todos los hilos
                    for (PrimeFinderThread thread : threads) {
                        thread.resumeThread();
                    }

                    monitor.notifyAll();
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
