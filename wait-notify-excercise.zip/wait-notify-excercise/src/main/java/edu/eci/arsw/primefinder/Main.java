package edu.eci.arsw.primefinder;

import edu.eci.arsw.primefinder.Control;

public class Main {
    public static void main(String[] args) {
        Control control = Control.newControl();
        control.start();
    }
}