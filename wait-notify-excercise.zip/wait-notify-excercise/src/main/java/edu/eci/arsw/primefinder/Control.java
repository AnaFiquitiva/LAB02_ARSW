package edu.eci.arsw.primefinder;

import java.util.Scanner;

/**
 * Clase Control que gestiona el ciclo de vida de los hilos buscadores.
 * Se encarga de pausarlos cada 5 segundos, mostrar estadísticas y
 * esperar la entrada del usuario para reanudar.
 */
public class Control extends Thread {

    private final static int NTHREADS = 3;
    private final static int MAXVALUE = 30000000;
    private final static int TMILISECONDS = 5000;

    private final int NDATA = MAXVALUE / NTHREADS;
    private final PrimeFinderThread[] pft;

    // Monitor único compartido entre Control y todos los PrimeFinderThread
    private final Object monitor = new Object();

    private Control() {
        super();
        this.pft = new PrimeFinderThread[NTHREADS];

        // Creación de hilos con rangos balanceados
        for (int i = 0; i < NTHREADS - 1; i++) {
            pft[i] = new PrimeFinderThread(i * NDATA, (i + 1) * NDATA, monitor);
        }
        pft[NTHREADS - 1] = new PrimeFinderThread((NTHREADS - 1) * NDATA, MAXVALUE + 1, monitor);
    }

    public static Control newControl() {
        return new Control();
    }

    @Override
    public void run() {
        // Iniciar todos los hilos trabajadores
        for (PrimeFinderThread thread : pft) {
            thread.start();
        }

        Scanner scanner = new Scanner(System.in);

        try {
            // El ciclo continúa mientras haya hilos trabajando
            while (estaAlgunHiloVivo()) {

                // 1. Esperar el intervalo de tiempo (5 segundos)
                Thread.sleep(TMILISECONDS);

                // 2. PAUSAR: Cambiar el estado de los hilos a pausado
                for (PrimeFinderThread thread : pft) {
                    thread.setPaused(true);
                }

                // 3. REPORTE: Mostrar cuántos primos se han encontrado
                System.out.println("Primos encontrados hasta ahora: " + getTotalPrimes());
                System.out.println("Presiona ENTER para continuar...");

                // 4. ESPERAR: El hilo Control se bloquea esperando la entrada
                scanner.nextLine();

                // 5. REANUDAR: Cambiar estado y notificar a través del monitor
                synchronized (monitor) {
                    for (PrimeFinderThread thread : pft) {
                        thread.setPaused(false);
                    }
                    // Despierta a todos los hilos que están en monitor.wait()
                    monitor.notifyAll();
                }
                System.out.println("Reanudando búsqueda\n");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            scanner.close();
        }

        System.out.println("Proceso completado. Total de primos: " + getTotalPrimes());
    }

    /**
     * Suma el total de primos encontrados por cada hilo individual.
     */
    private int getTotalPrimes() {
        int total = 0;
        for (PrimeFinderThread thread : pft) {
            total += thread.getPrimesFound();
        }
        return total;
    }

    /**
     * Verifica si todavía existen hilos en ejecución para continuar el ciclo de pausa.
     */
    private boolean estaAlgunHiloVivo() {
        for (PrimeFinderThread thread : pft) {
            if (thread.isAlive()) return true;
        }
        return false;
    }
}