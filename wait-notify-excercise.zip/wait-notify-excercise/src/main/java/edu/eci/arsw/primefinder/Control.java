/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wait.notify-excercise.edu.eci.arsw.primefinder;

public class Control extends Thread {

    private final static int NTHREADS = 3;
    private final static int MAXVALUE = 30000000;
    private final static int TMILISECONDS = 5000;

    private final int NDATA = MAXVALUE / NTHREADS;

    private PrimeFinderThread pft[];

    Object monitor = new Object();

    private Control() {
        super();
        this.pft = new PrimeFinderThread[NTHREADS]; // Inicializar el arreglo pft

        Object monitor = new Object(); // Crear el monitor

        int i;
        for (i = 0; i < NTHREADS - 1; i++) {
            PrimeFinderThread elem = new PrimeFinderThread(i * NDATA, (i + 1) * NDATA, monitor);
            pft[i] = elem;
        }
        pft[i] = new PrimeFinderThread(i * NDATA, MAXVALUE + 1, monitor);
    }


    public static Control newControl() {
        return new Control();
    }

    @Override
    public void run() {
        Object monitor = new Object();
        Thread controller = new Thread(new PauseController(TMILISECONDS, monitor, pft));
        controller.setDaemon(true);
        controller.start();

        for (int i = 0; i < NTHREADS; i++) {
            pft[i] = new PrimeFinderThread(i * NDATA, (i + 1) * NDATA, monitor);
            pft[i].start();
        }

        for (int i = 0; i < NTHREADS; i++) {
            try {
                pft[i].join();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }


}
